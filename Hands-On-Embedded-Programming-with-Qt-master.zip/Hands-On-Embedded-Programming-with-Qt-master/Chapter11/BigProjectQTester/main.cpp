#include "Test_HVACController.h"

QTEST_MAIN(Test_HVACController)
