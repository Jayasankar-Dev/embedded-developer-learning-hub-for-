#include "Test_HVACController.h"

Test_HVACController::Test_HVACController(QObject *parent) : QObject(parent)
{

}
