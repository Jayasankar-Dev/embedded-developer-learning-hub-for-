#include "TemperatureSensorIF.h"

TemperatureSensorIF::TemperatureSensorIF(QObject *parent) : QObject(parent)
{

}
