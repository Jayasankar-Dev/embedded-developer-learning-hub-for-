Here you will find a few pieces of "Bonus Code." It includes little
things I have written to make programming in Qt a little easier.

** All code is provided AS-IS. No warranty is made for fitness of the
   code for any function. By using this code, you assume all
   responsibility for testing, debugging, and verification.


Enjoy!
-John
